sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("disp.cred.seg.zdispcred.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);